from node import Node
from maze import Maze
import string

goal = ['0','1','2','3','4','5','6','7','8','9'] + list(string.ascii_lowercase) + list(string.ascii_uppercase)
print goal